# This package will contain the spiders of your Scrapy project
oethod='POST',
#
# Please refer to the documentation for information on how to create and manage
# your spiders.
