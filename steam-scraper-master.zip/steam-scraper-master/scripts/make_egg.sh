!#/bin/bash

python setup.py bdist_egg
